module Reductions
    (isDoubleNot, hasDoubleNot, reduceDoubleNot, reduceDeMorgan) where

import Control.Applicative
import Control.Monad
import Data.Foldable (toList)
import Data.List
import Data.Monoid
import Data.Traversable (fmapDefault, foldMapDefault)
import Data.Typeable
import Domain.Algebra.Boolean
import Domain.Logic.Formula

isDoubleNot :: Logic a -> Bool
isDoubleNot (Not(Not _)) = True
isDoubleNot _            = False

hasDoubleNot :: Logic a -> Bool
hasDoubleNot (p:<->:q)    = (||) (hasDoubleNot p)  (hasDoubleNot q)
hasDoubleNot (p:->:q)     = (||) (hasDoubleNot p)  (hasDoubleNot q)
hasDoubleNot (p:&&:q)     = (||) (hasDoubleNot p)  (hasDoubleNot q)
hasDoubleNot (p:||:q)     = (||) (hasDoubleNot p)  (hasDoubleNot q)
hasDoubleNot (Not(Not p)) = (||) True (hasDoubleNot p)
hasDoubleNot (Not p)      = (||) False (hasDoubleNot p)
hasDoubleNot p            = isDoubleNot p

reduceDoubleNot:: Logic a -> Logic a
reduceDoubleNot (Not(Not p)) = reduceDoubleNot p
reduceDoubleNot (Not p)      = (Not (reduceDoubleNot p))
reduceDoubleNot (p:<->:q)    = (reduceDoubleNot p) :<->: (reduceDoubleNot q)
reduceDoubleNot (p:->:q)     = (reduceDoubleNot p) :->:  (reduceDoubleNot q)
reduceDoubleNot (p:&&:q)     = (reduceDoubleNot p) :&&:  (reduceDoubleNot q)
reduceDoubleNot (p:||:q)     = (reduceDoubleNot p) :||:  (reduceDoubleNot q)
reduceDoubleNot p            = p

reduceDeMorgan:: Logic a -> Logic a
reduceDeMorgan (Not(p:&&:q)) = reduceDeMorgan (Not(p):||:Not(q))
reduceDeMorgan (Not(p:||:q)) = reduceDeMorgan (Not(p):&&:Not(q))
reduceDeMorgan (p:<->:q)     = (reduceDeMorgan p):<->:(reduceDeMorgan q)
reduceDeMorgan (p:->:q)      = (reduceDeMorgan p):->: (reduceDeMorgan q)
reduceDeMorgan (p:&&:q)      = (reduceDeMorgan p) :&&: (reduceDeMorgan q)
reduceDeMorgan (p:||:q)      = (reduceDeMorgan p) :||: (reduceDeMorgan q)
reduceDeMorgan (Not p)       = Not(reduceDeMorgan p)
reduceDeMorgan p             = p